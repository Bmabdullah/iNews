//
//  NavigationControllClass.swift
//  iNews
//
//  Created by AL Mustakim on 22/4/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//
import UIKit


@IBDesignable
class NavigationControllClass: UINavigationItem {


    
    
    @IBInspectable
     var cornerRadius: CGFloat {
         get {
             return layer.cornerRadius
         }
         set {
             layer.cornerRadius = newValue
         }
     }

     @IBInspectable
     var borderWidth: CGFloat {
         get {
             return layer.borderWidth
         }
         set {
             layer.borderWidth = newValue
         }
     }
     
     @IBInspectable
     var borderColor: UIColor? {
         get {
             if let color = layer.borderColor {
                 return UIColor(cgColor: color)
             }
             return nil
         }
         set {
             if let color = newValue {
                 layer.borderColor = color.cgColor
             } else {
                 layer.borderColor = nil
             }
         }
     }
     
     @IBInspectable
     var shadowRadius: CGFloat {
         get {
             return layer.shadowRadius
         }
         set {
             layer.shadowRadius = newValue
         }
     }
     
     @IBInspectable
     var shadowOpacity: Float {
         get {
             return layer.shadowOpacity
         }
         set {
             layer.shadowOpacity = newValue
         }
     }
     
     @IBInspectable
     var shadowOffset: CGSize {
         get {
             return layer.shadowOffset
         }
         set {
             layer.shadowOffset = newValue
         }
     }
     
     @IBInspectable
     var shadowColor: UIColor? {
         get {
             if let color = layer.backgroundColor {
                 return UIColor(cgColor: color)
             }
             return nil
         }
         set {
             if let color = newValue {
                 layer.shadowColor = color.cgColor
             } else {
                 layer.shadowColor = nil
             }
         }
     }
}
