//
//  Connection.swift
//  iNews
//
//  Created by AL Mustakim on 19/4/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//

import Foundation
import UIKit
extension LeatestViewController{

    func connectionCheck() {
           
           do {
               self.checkInternet = try CheckingInternet.init()
               
               if self.checkInternet!.connection != .unavailable {
                   print("Internet Available")
                  // self.gettingUserIPAddress()
                  // self.getData()
               }
               else {
                   print("Internet Unavailable")
                   let alert = UIAlertController(title: "No Connection !!", message: "Connect to the internet and restart the app to get data.", preferredStyle: .alert)
                   
                   alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction!) in
                  
                   } ))
                   self.present(alert, animated: true)
               }
           }
           catch  {
               
               print(error.localizedDescription)
           }
       }
}


