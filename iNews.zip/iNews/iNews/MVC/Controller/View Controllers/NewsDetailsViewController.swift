//
//  NewsDetailsViewController.swift
//  iNews
//
//  Created by AL Mustakim on 19/4/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//

import UIKit
import WebKit

class NewsDetailsViewController: UIViewController {

    @IBOutlet weak var detailsWebView: WKWebView!
    
    var linkUrl = String()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = false
        let url = URL(string: "\(linkUrl)")!
        detailsWebView.load(URLRequest(url: url))
        print(linkUrl)
    }
    


}
