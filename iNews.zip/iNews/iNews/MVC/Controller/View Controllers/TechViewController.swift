//
//  SecondViewController.swift
//  iNews
//
//  Created by AL Mustakim on 18/4/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//

import UIKit

class TechViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

