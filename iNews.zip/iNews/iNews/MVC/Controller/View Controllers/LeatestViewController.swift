//
//  FirstViewController.swift
//  iNews
//
//  Created by AL Mustakim on 18/4/20.
//  Copyright © 2020 AL Mustakim. All rights reserved.
//

import UIKit

class LeatestViewController: UIViewController , UITableViewDelegate , UITableViewDataSource {
  
    
    @IBOutlet weak var leatestNewsTableView: UITableView!
    
    var newsArr = [News]()
    
    
    var checkInternet: CheckingInternet?

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.isNavigationBarHidden = true
       // navigationController?.navigationBar.barTintColor = UIColor.clear
       
        connectionCheck()
        getData()
    
    }

    override func viewWillAppear(_ animated: Bool) {
        
        navigationController?.isNavigationBarHidden = true
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return newsArr.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LeatestNewsTableViewCell
        let str = newsArr[indexPath.row].published ?? ""
        
        let imageUrl = URL(string: newsArr[indexPath.row].image ?? "")
              
              if imageUrl != nil {
                  UIImage.getImage(url: imageUrl!) { (profileImg) in
                      
                      cell.newsImage.image = profileImg
                  }
              }
              else {
                cell.newsImage.image = #imageLiteral(resourceName: "second")
        }
        
        cell.newsTitle.text = newsArr[indexPath.row].title
        cell.authorName.text = newsArr[indexPath.row].author
        cell.publishDate.text = String(str.prefix(20))
        cell.newsDetails.text = newsArr[indexPath.row].description
        
        
        
        return cell
        
     }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 380
        
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let ve = storyboard?.instantiateViewController(withIdentifier: "details") as! NewsDetailsViewController
        ve.linkUrl = newsArr[indexPath.row].url ?? "www.inews.bmabdullah.com"
        navigationController?.pushViewController(ve, animated: true)

    }
    
    

}


extension LeatestViewController{

    func connectionCheck() {
           
           do {
               self.checkInternet = try CheckingInternet.init()
               
               if self.checkInternet!.connection != .unavailable {
                   print("Internet Available")
                  // self.gettingUserIPAddress()
                  // self.getData()
               }
               else {
                   print("Internet Unavailable")
                   let alert = UIAlertController(title: "No Connection !!", message: "Connect to the internet and restart the app to get data.", preferredStyle: .alert)
                   
                   alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action:UIAlertAction!) in
                  
                   } ))
                   self.present(alert, animated: true)
               }
           }
           catch  {
               
               print(error.localizedDescription)
           }
       }
}

extension LeatestViewController{
    func getData(){

           guard let url = URL(string: "https://api.currentsapi.services/v1/latest-news") else { return }
           var request = URLRequest(url: url)
           request.httpMethod = "GET"
           request.setValue("application/json", forHTTPHeaderField: "Content-Type")
         //   request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
          request.addValue("nmKmV02V3KDzsZctn8UQp6jJjS36kqWCQgGyhipzbJhDo4JN", forHTTPHeaderField: "Authorization")
           
        print(Data.self)
    
           let task = URLSession.shared.dataTask(with: request) { data, response, error in
              // print(response)
               if let data = data {
                
               // print("@@@@@@")
                               do {
                                   let responseModel = try JSONDecoder().decode(Base.self, from: data)
                                
                                print("responce Model for user : " , responseModel)
                                
                            
                                   DispatchQueue.main.async {
                                    
                                    self.newsArr.append(contentsOf: responseModel.news!)
                                    
                                
                                    self.leatestNewsTableView.reloadData()
                                }
                                
                               }
                               catch {
                                //print("!!!!!!!!")
                                   print(error.localizedDescription)
                                   return
                               }
                           }
            
           }
    task.resume()
           
       }

}


