
import Foundation
struct Base : Codable {
	let status : String?
	let news : [News]?
	let page : Int?

	enum CodingKeys: String, CodingKey {

		case status = "status"
		case news = "news"
		case page = "page"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		status = try values.decodeIfPresent(String.self, forKey: .status)
		news = try values.decodeIfPresent([News].self, forKey: .news)
		page = try values.decodeIfPresent(Int.self, forKey: .page)
	}

}
