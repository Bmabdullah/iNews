

import Foundation
struct News : Codable {
	let id : String?
	let title : String?
	let description : String?
	let url : String?
	let author : String?
	let image : String?
	let language : String?
	let category : [String]?
	let published : String?

	enum CodingKeys: String, CodingKey {

		case id = "id"
		case title = "title"
		case description = "description"
		case url = "url"
		case author = "author"
		case image = "image"
		case language = "language"
		case category = "category"
		case published = "published"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		id = try values.decodeIfPresent(String.self, forKey: .id)
		title = try values.decodeIfPresent(String.self, forKey: .title)
		description = try values.decodeIfPresent(String.self, forKey: .description)
		url = try values.decodeIfPresent(String.self, forKey: .url)
		author = try values.decodeIfPresent(String.self, forKey: .author)
		image = try values.decodeIfPresent(String.self, forKey: .image)
		language = try values.decodeIfPresent(String.self, forKey: .language)
		category = try values.decodeIfPresent([String].self, forKey: .category)
		published = try values.decodeIfPresent(String.self, forKey: .published)
	}

}
